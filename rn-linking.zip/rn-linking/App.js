import React from 'react';
import { StyleSheet, View, Text, Linking, Image } from 'react-native';
import ImagemIFAL from './components/Imagem';

const App = () => {
  return (
    <View style={estilos.recipiente}>
      <View style={estilos.recipienteSecao}>
        <ImagemIFAL />
        <Text style={estilos.titulo}>RN Linking</Text>
        <Text style={estilos.descricaoSecao}>
          Clique{' '}
          <Text
            style={estilos.hyperLink}
            onPress={() => {
              Linking.openURL('https://aboutreact.com');
            }}>
            aqui
          </Text>{' '}
          para ir para AboutReact.
        </Text>
        <Text style={estilos.equipe}>Equipe 5</Text>
      </View>
    </View>
  );
};

export default App;

const estilos = StyleSheet.create({
  recipiente: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    textAlign: 'center',
    padding: 15,
  },
  titulo: {
    fontSize: 24,
    fontWeight: '700',
    color: 'black',
  },
  equipe: {
    fontSize: 20,
    fontWeight: '500',
    color: 'blue',
    marginTop: 6,
  },
  recipienteSecao: {
    marginTop: 10,
  },
  descricaoSecao: {
    marginTop: 10,
    fontSize: 18,
    fontWeight: '400',
    color: 'black',
  },
  hyperLink: {
    color: '#2980b9',
  },
});

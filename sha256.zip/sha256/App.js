import React, { useState } from 'react';
import {
  SafeAreaView,
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import ImagemIFAL from './components/Imagem';
const jssha = require('js-sha256');

const App = () => {
  const [textoEntrada, setTextoEntrada] = useState('');
  const [texto, setTexto] = useState('');

  async function conversor() {
    const sha = jssha.sha256(textoEntrada);
    setTexto(sha);
  }
  return (
    <View style={estilos.recipiente}>
      <ImagemIFAL />
      <Text style={estilos.estiloTitulo}>Conversão para SHA256</Text>
      <Text style={estilos.estiloTexto}>Texto a ser codificado:</Text>
      <TextInput
        style={estilos.estiloTextoEntrada}
        onChangeText={(textoEntrada) => setTextoEntrada(textoEntrada)}
        placeholder="Insira o texto aqui"
        value={textoEntrada}
      />
      <TouchableOpacity style={estilos.estiloBotao} onPress={conversor}>
        <Text style={estilos.estiloTextoBotao}>Codificar</Text>
      </TouchableOpacity>
      <Text style={estilos.estiloTexto}>{texto}</Text>
    </View>
  );
};
export default App;

const estilos = StyleSheet.create({
  recipiente: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
  },
  estiloTitulo: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
    fontWeight: '500',
  },
  estiloTexto: {
    textAlign: 'left',
    margin: 10,
    marginLeft: 25,
    fontSize: 16,
    fontWeight: '500',
  },
  estiloTextoEntrada: {
    height: 40,
    marginLeft: 30,
    marginRight: 30,
  },
  estiloBotao: {
    backgroundColor: '#007500',
    borderColor: '#007500',
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 50,
    marginRight: 50,
    marginTop: 10,
  },
  estiloTextoBotao: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
});

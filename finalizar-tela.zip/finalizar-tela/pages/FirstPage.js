

import React from 'react';
import {Button, View, Text, SafeAreaView} from 'react-native';

const FirstPage = ({navigation}) => {
  const ifal = 'Ifal Palmeira';
  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={{flex: 1, padding: 16}}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Text
            style={{
              fontSize: 25,
              textAlign: 'center',
              marginBottom: 16,
            }}>
            Essa é a primeira tela do App
          </Text>
          <Button
            title="Ir para segunda tela"
            onPress={() =>
              navigation.replace('SecondPage', {
                someParam: ifal,
              })
            }
          />
          <Text>O texto a seguir irá para a próxima tela:</Text>
          <Text style={{color:'green', fontWeight:'bold'}}>{ifal}</Text>
        </View>
        <Text style={{textAlign: 'center', color: 'grey'}}>
         www2.ifal.edu.br/campus/palmeira
        </Text>
      </View>
    </SafeAreaView>
  );
};

export default FirstPage;
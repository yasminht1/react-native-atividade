import * as React from 'react';
import { View, StyleSheet, Image } from 'react-native';

export default function ImagemIFAL() {
  return (
    <View style={styles.estiloImagem}>
      <Image style={styles.logo} source={require('../imagens/IFAL_Logo.png')} />
    </View>
  );
}

const styles = StyleSheet.create({
  estiloImagem: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  logo: {
    height: 70,
    width: 250,
  }
});

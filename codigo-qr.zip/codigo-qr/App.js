import React, { useState } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import ImagemIFAL from './components/Imagem';

const App = () => {
  const [textoEntrada, setTextoEntrada] = useState('');
  const [valorQRCode, setValorQRCode] = useState('');

  return (
    <View style={estilos.recipiente}>
      <ImagemIFAL />
      <Text style={estilos.titulo}>Geração de código QR</Text>
      <QRCode value={valorQRCode ? valorQRCode : 'NA'} size={180} />
      <Text style={estilos.texto}>Valor do código QR:</Text>
      <TextInput
        style={estilos.estiloTextoEntrada}
        onChangeText={(textoEntrada) => setTextoEntrada(textoEntrada)}
        placeholder="Insira o valor do QR Code"
        value={textoEntrada}
      />
      <TouchableOpacity
        style={estilos.estiloBotao}
        onPress={() => setValorQRCode(textoEntrada)}>
        <Text style={estilos.estiloTextoBotao}>Gerar código</Text>
      </TouchableOpacity>
    </View>
  );
};
export default App;

const estilos = StyleSheet.create({
  recipiente: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
  },
  titulo: {
    fontSize: 24,
    fontWeight: '700',
    textAlign: 'center',
    margin: 10,
  },
  texto: {
    fontSize: 16,
    textAlign: 'center',
    margin: 15,
  },
  estiloTextoEntrada: {
    flexDirection: 'row',
    height: 40,
    marginTop: 5,
    marginLeft: 35,
    marginRight: 35,
    margin: 10,
  },
  estiloBotao: {
    backgroundColor: '#007500',
    borderWidth: 0,
    color: '#FFFFFF',
    borderColor: '#007500',
    alignItems: 'center',
    borderRadius: 5,
    marginTop: 10,
    padding: 10,
  },
  estiloTextoBotao: {
    color: 'white',
    fontWeight: '500',
    paddingVertical: 5,
    fontSize: 15,
  },
});

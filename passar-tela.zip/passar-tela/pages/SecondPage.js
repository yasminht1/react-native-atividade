//This is an example code for Navigator// 
import React, { Component } from 'react';
//import react in our code. 
import { StyleSheet, View, Text, Image} from 'react-native';
//import all the components we are going to use.

import ifal from '../images/ifal.png'

export default class SecondPage extends Component {
  static navigationOptions = {
    title: 'Segunda Tela',
    //Sets Header text of Status Bar
  };
  render() {
    const { navigate } = this.props.navigation;
    return (
      <View style={styles.container}>
        <Text>Você está na segunda tela</Text>
        <Image source={ifal} style={{width:'300px', height:'100px'}}></Image>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
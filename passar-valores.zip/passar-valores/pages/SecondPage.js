import React from 'react';
import {SafeAreaView, StyleSheet, View, Text, Image} from 'react-native';
import ifal from '../assets/ifal.png';

const SecondPage = ({route}) => {
  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={styles.container}>
        <Text style={styles.heading}>
          Valor passado com sucesso!
        </Text>
        <Text style={styles.textStyle}>
         Seu nome e turma: {route.params.paramKey}
        </Text>
        <Image source={ifal} style={{ width: '300px', height: '100px' }} /> 
      </View>
    </SafeAreaView>
  );
};

export default SecondPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
  },
  heading: {
    fontSize: 25,
    textAlign: 'center',
    marginVertical: 10,
  },
  textStyle: {
    marginBottom: '16px',
    textAlign: 'center',
    fontSize: 16,
    marginVertical: 10,
  },
});
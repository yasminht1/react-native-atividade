import React, {useState} from 'react';
import {
  TextInput,
  SafeAreaView,
  View,
  StyleSheet,
  Text,
  Image
} from 'react-native';
import Filter from 'bad-words';
import ImagemIFAL from './components/Imagem';
const App = () => {
  let [valorEntrada, setvalorEntrada] = useState('');

  const filter = new Filter();
  filter.addWords('merda','bosta','idiota','feio','feia')

  const escutarEvento = (value) => {
    setvalorEntrada(value);
  };

  return (
    <>
    
    <SafeAreaView style={{flex: 1}}>
      <View style={styles.container}>
      <ImagemIFAL />
        <Text style={styles.header}>
          Filtro para remover
          {'\n'}
          palavras de baixo calão
        </Text>

        <TextInput
          value={valorEntrada}
          onChangeText={escutarEvento}
          placeholder={'Por favor, insira um palavrão :)'}
          style={styles.inputStyle}
        />
        <Text style={styles.insertedTextStyle}>
          {valorEntrada ? filter.clean(valorEntrada) : ''}
        </Text>
      </View>
    </SafeAreaView>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#ffffff',
    padding: 16,
  },
  header: {
    fontSize: 22,
    textAlign: 'center',
    marginBottom: 16,
  },
  textStyle: {
    marginVertical: 10,
    textAlign: 'center',
  },
  insertedTextStyle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginVertical: 20,
    textAlign: 'center',
  },
  inputStyle: {
    width: '100%',
    height: 44,
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#ecf0f1',
  },
});

export default App;
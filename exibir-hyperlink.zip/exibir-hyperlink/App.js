import React from 'react';
import { StyleSheet, View, Text, Linking } from 'react-native';
import Hyperlink from 'react-native-hyperlink';
import ImagemIFAL from './components/Imagem';

const App = () => {
  return (
    <View style={estilos.recipiente}>
      <View style={estilos.recipienteSecao}>
        <ImagemIFAL />
        <Text style={estilos.titulo}>Hyperlink</Text>
        <Hyperlink
          linkDefault={true}
          linkStyle={estilos.hyperLink}
          linkText={(url) => (url === 'https://aboutreact.com' ? 'aqui' : url)}>
          <Text style={estilos.descricaoSecao}>
            Clique https://aboutreact.com para ir para AboutReact.
          </Text>
        </Hyperlink>
        <Text style={estilos.equipe}>Equipe 5</Text>
      </View>
    </View>
  );
};

export default App;

const estilos = StyleSheet.create({
  recipiente: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    textAlign: 'center',
    padding: 15,
  },
  titulo: {
    fontSize: 24,
    fontWeight: '700',
    color: 'black',
  },
  equipe: {
    fontSize: 20,
    fontWeight: '500',
    color: 'blue',
    marginTop: 6,
  },
  recipienteSecao: {
    marginTop: 10,
  },
  descricaoSecao: {
    marginTop: 10,
    fontSize: 18,
    fontWeight: '400',
    color: 'black',
  },
  hyperLink: {
    color: '#2980b9',
  },
});

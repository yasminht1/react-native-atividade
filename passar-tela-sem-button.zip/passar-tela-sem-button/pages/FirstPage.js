//This is an example code for Navigator// 
import React, { Component } from 'react';
//import react in our code. 
import { StyleSheet, View, Button, Text, TouchableOpacity} from 'react-native';
//import all the components we are going to use.

export default class FirstPage extends Component {
  static navigationOptions = {
    title: 'Primeira Tela',
    //Sets Header text of Status Bar
    headerStyle: {
      backgroundColor: '#333',
      //Sets Header color
    },
    headerTintColor: '#fff',
    //Sets Header text color
    headerTitleStyle: {
      fontWeight: 'bold',
      //Sets Header text style
    },
  };

  render() {
    const { navigate } = this.props.navigation;
    return (
      <TouchableOpacity style={styles.container} onPress={() =>navigate('SecondPage')}>

        <Text>Toque em qualquer lugar da tela para
        trocar de tela</Text>
        <Text style={styles.texto}>Grupo 5</Text>
      </TouchableOpacity>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  texto: {
    marginTop: '16px',
    color: '#fff',
    fontSize: '16px',
    fontWeight: 'bold',
    backgroundColor: '#333',
    paddingTop: '10px',
    paddingRight: '20px',
    paddingBottom: '10px',
    paddingLeft: '20px',
    borderRadius: '1px'

  },

});
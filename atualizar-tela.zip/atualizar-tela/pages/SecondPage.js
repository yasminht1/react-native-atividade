// Refresh Previous Screen after Going Back in React Navigation
// https://aboutreact.com/refresh-previous-screen-react-navigation/

import React from 'react';
import {Image, View, Text, SafeAreaView} from 'react-native';
import computer from '../assets/computer.gif'

const SecondPage = () => {
  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={{flex: 1, padding: 16}}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Text
            style={{
              fontSize: 25,
              textAlign: 'center',
              marginBottom: 16,
            }}>
            Essa é a segunda tela do App
          </Text>

          <Image source={computer} style={{ width: 305, height: 159 }} /> 
        </View>

      </View>
    </SafeAreaView>
  );
};

export default SecondPage;